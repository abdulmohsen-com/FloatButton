package com.example.android.testnewcomponents;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.getbase.floatingactionbutton.FloatingActionButton;

import java.util.Random;

public class MyApplication extends AppCompatActivity {
    private FloatingActionButton Setting;
    private FloatingActionButton Phone;
    private FloatingActionButton Rating;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_application);
        Setting = findViewById(R.id.Setting);
        Phone = findViewById(R.id.Phone);
        Rating = findViewById(R.id.Rating);
        Setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyApplication.this, Settings.class);
                startActivity(intent);
            }
        });
        //_____________________________________________________
        Phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder myAlertBuilder = new AlertDialog.Builder(MyApplication.this);
                myAlertBuilder.setTitle("Warning");
                myAlertBuilder.setMessage("You're About To Leave The Application, Are You Sure?");
                myAlertBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String phone = "+96594431440";
                        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
                        startActivity(intent);
                    }
                });
                myAlertBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                myAlertBuilder.show();
            }


        });
        //__________________________________
        Rating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyApplication.this, Rating.class);
                startActivity(intent);
            }
        });
    }
}
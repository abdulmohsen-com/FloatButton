package com.example.android.testnewcomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

public class Rating extends AppCompatActivity {
   private SeekBar seekBar;
   private TextView counter;
   private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);
        seekBar = findViewById(R.id.greenSeekBar1);
        counter = findViewById(R.id.textView);
        textView = findViewById(R.id.changableText);
        seekBar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int i, boolean b) {

                counter.setText(i+"");

                String rateService = "Your Rating: ";
                if(seekBar.getProgress()<=25){
                    textView.setText(rateService+"Bad");
                }
                else if(seekBar.getProgress()<=50){
                    textView.setText(rateService+"Good");
                }
                else if(seekBar.getProgress()<=75){
                    textView.setText(rateService+"Great");
                }
                else{
                    textView.setText(rateService+"Excellent");
                }
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {

            }
        });
    }
}
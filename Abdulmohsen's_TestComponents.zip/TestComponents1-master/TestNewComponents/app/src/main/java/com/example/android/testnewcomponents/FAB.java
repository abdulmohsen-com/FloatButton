package com.example.android.testnewcomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.getbase.floatingactionbutton.FloatingActionButton;
import com.getbase.floatingactionbutton.FloatingActionsMenu;

public class FAB extends AppCompatActivity {
       private FloatingActionButton floatingActionButton;
       private FloatingActionButton floatingActionButton1;
       private FloatingActionButton floatingActionButton2;
       private FloatingActionButton floatingActionButton3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_f_a_b);

//        go to checkBox activity
        floatingActionButton =  findViewById(R.id.CheckBoxFAB);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FAB.this,CheckBox.class);
                startActivity(intent);
            }
        });
//        go to SeekBar activity
        floatingActionButton1 =  findViewById(R.id.SeekBarFAB);
        floatingActionButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FAB.this,SeekBar.class);
                startActivity(intent);
            }
        });
        //go to radioButtons activity
        floatingActionButton2 = findViewById(R.id.RadioFAB);
        floatingActionButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FAB.this,RadioButtons.class);
                startActivity(intent);
            }
        });
        floatingActionButton3 = findViewById(R.id.SwitchFAB);
        floatingActionButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FAB.this,Switch.class);
                startActivity(intent);
            }
        });


    }
}

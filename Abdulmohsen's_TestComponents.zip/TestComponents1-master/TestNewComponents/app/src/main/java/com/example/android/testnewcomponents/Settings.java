package com.example.android.testnewcomponents;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Switch;

public class Settings extends AppCompatActivity {
    View view;
   private Switch DL;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        view = this.getWindow().getDecorView();
        DL = findViewById(R.id.SwitchDL);
       DL.setOnClickListener(new View.OnClickListener() {
           int DM = R.color.DarkMode;
           int LM = R.color.LightMode;
           public void onClick(View v) {
               if(DL.isChecked()){
                   view.setBackgroundColor(getResources().getColor(DM));
               }else {
                   view.setBackgroundColor(getResources().getColor(LM));
               }
           }
       });
       //___________________________________________________
    }
}